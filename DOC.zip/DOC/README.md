# AI ENGINEERING OPERATING SYSTEM
A deterministic, machine-readable framework for planning and generating SaaS apps end-to-end with multiple AI agents.

## STRUCTURE
```
DOC/
├── core/
│   ├── system-rules.md
│   ├── anti-hallucination-rules.md
│   └── planning-principles.md
├── agents/
│   ├── master_planner.agent.md
│   ├── integration_planner.agent.md
│   ├── frontend_planner.agent.md
│   ├── backend_planner.agent.md
│   └── reviewer.agent.md
├── knowledge/
│   ├── integration-rules/
│   │   ├── stripe.yaml
│   │   ├── sanity.yaml
│   │   ├── resend.yaml
│   │   ├── clerk.yaml
│   │   ├── database.yaml
│   │   └── posthog.yaml
│   ├── feature-maps/
│   │   └── feature-integration-map.json
│   ├── architecture-templates/
│   │   ├── standard_saas.yaml
│   │   ├── content_saas.yaml
│   │   └── marketplace_saas.yaml
│   ├── frontend-rules/
│   │   └── frontend-rules.md
│   └── backend-rules/
│       └── backend-rules.md
├── flows/
│   ├── data-flows/
│   │   ├── blog-flow.md
│   │   ├── payment-flow.md
│   │   └── auth-flow.md
│   └── system-flows/
│       ├── planning-flow.md
│       └── execution-flow.md
├── validation/
│   ├── checklists/
│   │   ├── pre-planning-checklist.md
│   │   └── pre-build-checklist.md
│   └── constraints/
│       └── constraints.md
└── execution/
    └── codegen-rules/
        ├── codegen-rules.md
        ├── output-format-rules.md
        └── cli-command-rules.md
```

## HOW TO USE WITH AN AI AGENT

1. Point the agent at `DOC/`.
2. Have the agent run `agents/master_planner.agent.md` with the user's free-text SaaS description.
3. Master planner orchestrates `integration_planner`, `frontend_planner`, `backend_planner`.
4. `reviewer.agent.md` validates the aggregated plan.
5. On `validation_report.status == "passed"` the plan is LOCKED.
6. The executor consumes `plan.json` per `flows/system-flows/execution-flow.md` and emits the project.

## PRECEDENCE
`core` > `validation/constraints` > `knowledge/integration-rules` > `knowledge/feature-maps` > `knowledge/architecture-templates` > `flows` > `execution`.

## EXTENDING
- New integration → add `knowledge/integration-rules/<name>.yaml`.
- New feature → add an entry in `knowledge/feature-maps/feature-integration-map.json`.
- New architecture → add `knowledge/architecture-templates/<name>.yaml`.

Unknown features or integrations cause the planner to BLOCK with `MISSING_KNOWLEDGE`. Add them to the knowledge base and re-run.
